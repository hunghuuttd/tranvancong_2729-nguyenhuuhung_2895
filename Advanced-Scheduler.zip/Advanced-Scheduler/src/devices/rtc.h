#ifndef RTC_H
#define RTC_H

typedef unsigned long time_t;

time_t rtc_get_time (void);

#endif
